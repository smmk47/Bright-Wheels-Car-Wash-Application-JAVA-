package sers;

public class PremiumService extends Service {
	// Additional properties or methods specific to PremiumService, if needed
	private int serviceCost;
	private String description;

	// Constructor
	public PremiumService(String serviceName, int serviceCost, int serviceID, String description) {
	   super(serviceName, serviceID);
	   this.serviceCost = serviceCost;
	   this.description = description;
	}

	public PremiumService() {
	   // Default constructor
	}

	// Getter and setter for PremiumService
	public int getServiceCost() {
	   return serviceCost;
	}

	public void setServiceCost(int serviceCost) {
	   this.serviceCost = serviceCost;
	}

	public String getDescription() {
	   return description;
	}

	public void setDescription(String description) {
	   this.description = description;
	}

	// Display method
	public void display() {
	   super.display();
	   System.out.println("Service Cost: " + serviceCost);
	   System.out.println("Description: " + description);
	}
	}