package sers;

//import CarWash.Service;

//Service class (base class)
 public class Service {

private String serviceType;
private int serviceID;  // New variable

// Constructors
public Service(String serviceName, int serviceID) {
   this.serviceType = serviceName;
   this.serviceID = serviceID;
}

public Service() {
   // Default constructor
}

// Getters and setters
public String getServiceType() {
   return serviceType;
}

public void setServiceType(String serviceType) {
   this.serviceType = serviceType;
}

public int getServiceID() {
   return serviceID;
}

public void setServiceID(int serviceID) {
   this.serviceID = serviceID;
}

// Display method
public void display() {
   System.out.println("Service Type: " + serviceType);
   System.out.println("Service ID: " + serviceID);
}
}
