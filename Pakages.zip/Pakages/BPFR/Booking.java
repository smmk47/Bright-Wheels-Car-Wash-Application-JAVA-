package BPFR;

import sers.Service;

public class Booking {
    private int bookingId;
    private String bookingTime;
    private String bookingDate;
    private String bookingStatus;

    public Payment payment;
    public Service service;
	public Feedback feedback ;
    
    public Service getService() {
        return service;
    }

    public void setService(Service s) {
        this.service=s;
		
    }
    public void setPayment(Payment p) {
        this.payment=p;
		
    }
    public Payment getPAyment() {
    	return payment;
    }
    
    
    
    public Booking() {
      
    }
    
    public Booking(int bookingId, String bookingTime, String selectedDate, String bookingStatus) {
        this.bookingId = bookingId;
        this.bookingTime = bookingTime;
        this.bookingDate = selectedDate;
        this.bookingStatus = bookingStatus;
    }

    public int getBookingId() {
        return bookingId;
    }

    
    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public String getBookingTime() {
        return bookingTime;
    }

    public void setBookingTime(String bookingTime) {
        this.bookingTime = bookingTime;
    }

    public String getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(String bookingDate) {
        this.bookingDate = bookingDate;
    }

    public String getBookingStatus() {
        return bookingStatus;
    }

    public void setBookingStatus(String bookingStatus) {
        this.bookingStatus = bookingStatus;
    }

    public String getBFeedback() {
        return "kuch ni hy idhar , Feeback ki class banani hy abhi wait karo";
    }

    public void setFeedback(String feedback) {
        
    }

    public void Pay_payment(String feedback) {
        
    }


    public void showAvailableSlots() {
        System.out.println("Available Slots: " + bookingTime + " on " + bookingDate);
    }

    public void giveFeedback(Feedback feedback) {
        this.feedback = feedback;
        //System.out.println("Feedback submitted: " + this.feedback);
    }
}
