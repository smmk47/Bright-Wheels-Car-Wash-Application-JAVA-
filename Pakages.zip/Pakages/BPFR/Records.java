package BPFR;

import java.util.ArrayList;

public class Records {
    private ArrayList<Payment> paymentRecords;
    private ArrayList<Booking> bookingRecords;

    public Records() {
        this.paymentRecords = new ArrayList<>();
        this.bookingRecords = new ArrayList<>();
    }

    public void addPaymentRecord(Payment payment) {
        paymentRecords.add(payment);
    }

    public void addBookingRecord(Booking booking) {
        bookingRecords.add(booking);
    }

    public ArrayList<Payment> getPaymentRecords() {
        return paymentRecords;
    }

    public ArrayList<Booking> getBookingRecords() {
        return bookingRecords;
    }

    public void displayPaymentRecords() {
        System.out.println("Payment Records:");
        for (Payment payment : paymentRecords) {
            System.out.println(payment.generateSlip());
        }
    }

    public void displayBookingRecords() {
        System.out.println("Booking Records:");
        for (Booking booking : bookingRecords) {
            System.out.println("Booking ID: " + booking.getBookingId() +
                    "\nTime: " + booking.getBookingTime() +
                    "\nDate: " + booking.getBookingDate() +
                    "\nStatus: " + booking.getBookingStatus());
        }
    }

    // You can add more methods for updating or searching records as needed.
}
