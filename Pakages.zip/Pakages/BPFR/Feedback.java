package BPFR;

public class Feedback {
    // Variables
    private String description;
    private int rating;
    private int feedbackID;
    private String serviceType;

    // Constructor
    public Feedback(String description, int rating, int feedbackID, String serviceType) {
        this.description = description;
        this.rating = rating;
        this.feedbackID = feedbackID;
        this.serviceType = serviceType;
    }

    public Feedback() {
       
    }
    
    // Function to store feedback
    public void storeFeedback() {
       
        System.out.println("Feedback stored successfully.");
    }

    // Function to display feedback
    public void displayFeedback() {
       
        System.out.println("Feedback ID: " + feedbackID);
        System.out.println("Service Type: " + serviceType);
        System.out.println("Rating: " + rating);
        System.out.println("Description: " + description);
        
    }

    // Getter and Setter methods for variables (if needed)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public int getFeedbackID() {
        return feedbackID;
    }

    public void setFeedbackID(int feedbackID) {
        this.feedbackID = feedbackID;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

   
}


