package BPFR;

public class Payment {
    private int paymentID;
    private int amount;
    private String status;
    private String date;
    private String mode;

    public Payment(int paymentID, int amount, String status, String date, String mode) {
        this.paymentID = paymentID;
        this.amount = amount;
        this.status = status;
        this.date = date;
        this.mode = mode;
    }

    public Payment() {

    }

	public int getPaymentID() {
        return paymentID;
    }

    public void setPaymentID(int x) {
        this.paymentID = x;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public void paymentMode(String newMode) {
        this.mode = newMode;
        System.out.println("Payment mode updated to " + newMode);
    }

    public String generateSlip() {
        return "Payment Slip\nPayment ID: " + paymentID + "\nAmount: " + amount + "\nStatus: " + status + "\nDate: " + date + "\nMode: " + mode;
    }

    public void updateRecords(int newAmount, String newStatus) {
        this.amount = newAmount;
        this.status = newStatus;
        System.out.println("Payment records updated");
    }

    public boolean validatePaymentInfo() {
        return paymentID != 0 && amount >= 0 && status != null && date != null && mode != null;
    }
    }

