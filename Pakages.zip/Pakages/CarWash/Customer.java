package CarWash;

import BPFR.Booking;
import BPFR.Payment;
import VR.Registration;
import sers.Service;

public class Customer extends Person {
	 private int customerId;
	 private String password; // Password should generally be kept private and may need additional security measures
	 Booking booking = new Booking();
	 Registration reg = new Registration();
	 
	 // Constructor
	 public Customer() {
	    
	 }
	 
	 public Customer(String name, String address, String email, String phone, int customerId, String password) {
	     super(name, address, email, phone);
	     this.customerId = customerId;
	     this.password = password;
	     
	     reg.setCustomerID(customerId);
	     reg.setRegistrationStatus("Registered");
	     
	 }

	 // Getter methods
	 public int getCustomerId() {
	     return customerId;
	 }

	 public String getPassword() {
	     return password;
	 }

	 
	 // Setter methods
	 public void SetBooking(Booking x) {

		 this.booking=x;
	 
	 }
	 public Booking GetBookng() {

		 return booking;
	 
	 }
	 
	 // Setter methods
	 public void setCustomerId(int customerId) {
	     this.customerId = customerId;
	 }

	 public void setPassword(String password) {
	     this.password = password;
	 }

	 // Display method (overrides the displayInfo method in Person)
	 @Override
	 public void displayInfo() {
	     super.displayInfo(); // Call the displayInfo method from the parent class
	     System.out.println("Customer ID: " + customerId);
	     System.out.println("Password: " + password);
	 }
	 public void BookService(Service s, Payment p) {
		 
		 booking.payment=p;
		 booking.service=s;
		 
	 }
	}