package CarWash;

public class Inventory {
    private int productID;
    private String product;
    private int quantity;

    // Constructor
    public Inventory(int productID, String product, int quantity) {
        this.productID = productID;
        this.product = product;
        this.quantity = quantity;
    }

    // Getter and Setter methods for ProductID
    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    // Getter and Setter methods for Product
    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    // Getter and Setter methods for Quantity
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Method to add a product
    public void addProduct(int productID, String product, int quantity) {
        this.productID = productID;
        this.product = product;
        this.quantity += quantity;
    }

    // Method to remove a product
    public void removeProduct(int quantityToRemove) {
        if (quantityToRemove <= quantity) {
            quantity -= quantityToRemove;
        } else {
            System.out.println("Error: Not enough quantity to remove.");
        }
    }

    // Method to update a product
    public void updateProduct(String newProduct, int newQuantity) {
        this.product = newProduct;
        this.quantity = newQuantity;
    }
}
