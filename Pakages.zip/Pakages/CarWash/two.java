package CarWash;

import java.util.ArrayList;
import java.util.List;

/*
class Records {
    private List<Payment> payments;
    private List<Booking> bookings;

    public Records() {
        this.payments = new ArrayList<>();
        this.bookings = new ArrayList<>();
    }

    // Payment-related methods
    public void addPayment(Payment payment) {
        payments.add(payment);
    }

    public List<Payment> getPayments() {
        return payments;
    }

    // Booking-related methods
    public void addBooking(Booking booking) {
        bookings.add(booking);
    }

    public List<Booking> getBookings() {
        return bookings;
    }

    // Other methods as needed

    public void showAllPayments() {
        System.out.println("All Payments:");
        for (Payment payment : payments) {
            System.out.println(payment.generateSlip());
        }
    }

    public void showAllBookings() {
        System.out.println("All Bookings:");
        for (Booking booking : bookings) {
            System.out.println("Booking ID: " + booking.getBookingId() +
                    "\nTime: " + booking.getBookingTime() +
                    "\nDate: " + booking.getBookingDate() +
                    "\nStatus: " + booking.getBookingStatus());
        }
    }
}
*/