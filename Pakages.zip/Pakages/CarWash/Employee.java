package CarWash;

public class Employee extends Person {

	 private int employeeId;
	 private String password; // Password should generally be kept private and may need additional security measures
	 private int salary;
	 private String workshift;
	 private String designation;

	 // Constructor
	 public Employee() {
	     
	 }
	 
	 public Employee(String name, String address, String email, String phone, int employeeId) {
	     super(name, address, email, phone);
	     this.employeeId = employeeId;
	 }

	 public Employee(String name, String address, String email, String phone,
	         int employeeId, String password, int salary, String workshift, String designation) {
	// Call the parameterized constructor of the superclass (Person)
	super(name, address, email, phone);
	this.employeeId = employeeId;
	this.password = password;
	this.salary = salary;
	this.workshift = workshift;
	this.designation = designation;
	}
	 
	 // Getter methods
	 public int getEmployeeId() {
	     return employeeId;
	 }

	 public String getPassword() {
	     return password;
	 }

	 public int getSalary() {
	     return salary;
	 }

	 public String getWorkshift() {
	     return workshift;
	 }

	 public String getDesignation() {
	     return designation;
	 }

	 // Setter methods
	 public void setEmployeeId(int employeeId) {
	     this.employeeId = employeeId;
	 }

	 public void setPassword(String password) {
	     this.password = password;
	 }

	 public void setSalary(int salary) {
	     this.salary = salary;
	 }

	 public void setWorkshift(String workshift) {
	     this.workshift = workshift;
	 }

	 public void setDesignation(String designation) {
	     this.designation = designation;
	 }

	 // Display method (overrides the displayInfo method in Person)
	 @Override
	 public void displayInfo() {
	     super.displayInfo(); // Call the displayInfo method from the parent class
	     System.out.println("Employee ID: " + employeeId);
	     System.out.println("Password: " + password);
	     System.out.println("Salary: " + salary);
	     System.out.println("Workshift: " + workshift);
	     System.out.println("Designation: " + designation);
	 }
	}
