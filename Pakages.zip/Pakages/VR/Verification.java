package VR;

public class Verification {
    private int verificationID;
    private int customerID;
    private String verificationStatus;

    // Constructor
    public Verification() {
        
    }
    public Verification(int verificationID, int customerID, String verificationStatus) {
        this.verificationID = verificationID;
        this.customerID = customerID;
        this.verificationStatus = verificationStatus;
    }

    // Getter and Setter methods for Verification ID
    public int getVerificationID() {
        return verificationID;
    }

    public void setVerificationID(int verificationID) {
        this.verificationID = verificationID;
    }

    // Getter and Setter methods for Customer ID
    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    // Getter and Setter methods for Verification Status
    public String getVerificationStatus() {
        return verificationStatus;
    }

    public void setVerificationStatus(String verificationStatus) {
        this.verificationStatus = verificationStatus;
    }

    // Verify method
    public void verify() {
        System.out.println("Verification process for ID " + verificationID + " is in progress...");       
        this.verificationStatus = "Verified";
        System.out.println("Verification completed. Status: " + verificationStatus);
    }
    
}

