package VR;



 public class Registration {
    private int registrationID;
    private int customerID;
    private String registrationStatus;
    
    Verification ver = new Verification();
    
    // Constructor
    public Registration() {
        
        
    }

    
    
    public Registration(int registrationID, int customerID, String registrationStatus) {
        this.registrationID = registrationID;
        this.customerID = customerID;
        this.registrationStatus = registrationStatus;
        ver.setCustomerID(customerID);
        ver.setVerificationID(registrationID);
        ver.setVerificationStatus("Pending");
    }
    
    // Getter and Setter methods for Registration ID
    public int getRegistrationID() {
        return registrationID;
    }

    public void setRegistrationID(int registrationID) {
        this.registrationID = registrationID;
    }

    // Getter and Setter methods for Customer ID
    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public String getRegistrationStatus() {
        return registrationStatus;
    }

    public void setRegistrationStatus(String registrationStatus) {
        this.registrationStatus = registrationStatus;
    }

    public void register() {
        System.out.println("Registration process for ID " + registrationID + " is in progress...");
       
        this.registrationStatus = "Registered";
        System.out.println("Registration completed. Status: " + registrationStatus);
    }
    
    

}